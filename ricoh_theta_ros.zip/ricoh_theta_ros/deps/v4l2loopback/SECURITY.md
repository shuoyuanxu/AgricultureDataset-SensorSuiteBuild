# Security Policy

## Reporting a Vulnerability

You can report vulnerability issues by opening a *confidential issue* on https://git.iem.at/zmoelnig/v4l2loopback/
