.. _ricoh_theta_ros: https://github.com/madjxatw/ricoh_theta_ros
.. _libuvc-theta: https://github.com/ricohapi/libuvc-theta
.. _libuvc-theta-sample: https://github.com/codetricity/libuvc-theta-sample.git
.. _v4l2loopback: https://github.com/umlaeute/v4l2loopback
.. _cv_camera: http://wiki.ros.org/cv_camera
.. _Equirec2Perspec: https://github.com/madjxatw/Equirec2Perspec
.. _libptp: http://libptp.sourceforge.net/
